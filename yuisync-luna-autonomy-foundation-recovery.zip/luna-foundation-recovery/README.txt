RECUPERACAO DA LUNA AUTONOMY FOUNDATION

1. Extraia os dois arquivos na raiz do repositorio YuiSync.
2. Confirme que esta na branch feat/luna-autonomy-foundation.
3. Execute:

   chmod +x apply-luna-foundation-recovery.sh
   ./apply-luna-foundation-recovery.sh

O script:
- aplica a fundacao completa que ficou ausente;
- preserva agenda, estoque, catalogo e RPC existentes;
- atualiza os testes estaticos antigos;
- valida testes da Luna, typecheck e build;
- nao faz commit nem merge automaticamente.

Depois, execute uma linha por vez:

   git add -A
   git commit -m "feat(luna): adicionar fundacao de autonomia e regressao"
   git push -u origin feat/luna-autonomy-foundation

Depois crie o PR:

   gh pr create --base main --head feat/luna-autonomy-foundation --title "feat(luna): adicionar fundacao de autonomia e regressao" --body "Adiciona estado operacional, eventos, tracing passivo, verificador e regressões permanentes sem substituir agenda, estoque ou persistência atuais."

E faça o merge:

   gh pr merge feat/luna-autonomy-foundation --merge --delete-branch --auto
