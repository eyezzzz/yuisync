#!/usr/bin/env bash
set -euo pipefail

ROOT="$(git rev-parse --show-toplevel 2>/dev/null || true)"
if [ -z "$ROOT" ]; then
  echo "Erro: execute este script dentro do repositorio YuiSync." >&2
  exit 1
fi
cd "$ROOT"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PATCH_FILE="$SCRIPT_DIR/yuisync-luna-autonomy-foundation.patch"

if [ ! -f "$PATCH_FILE" ]; then
  echo "Erro: patch nao encontrado ao lado do script: $PATCH_FILE" >&2
  exit 1
fi

BRANCH="$(git branch --show-current)"
if [ "$BRANCH" != "feat/luna-autonomy-foundation" ]; then
  echo "Erro: branch atual e '$BRANCH'. Use feat/luna-autonomy-foundation antes de continuar." >&2
  exit 1
fi

# Remove apenas o script temporario anterior; nao toca na infraestrutura existente.
rm -f fix-luna-foundation-validation.sh

# Aplica a fundacao somente se ela ainda nao estiver presente.
if [ ! -f server/lib/luna/operationState.js ]; then
  echo "Aplicando Luna Autonomy Foundation..."
  git apply --check "$PATCH_FILE"
  git apply "$PATCH_FILE"
else
  echo "A fundacao ja esta presente; pulando a reaplicacao do patch."
fi

# Atualiza testes estaticos antigos para os contratos atuais.
python3 - <<'PY'
from pathlib import Path
import re

path = Path('test/petbotStatic.test.mjs')
if not path.exists():
    raise SystemExit('Arquivo nao encontrado: test/petbotStatic.test.mjs')

text = path.read_text()
original = text

old_confirmation = (
    r"  assert\.match\(localChat, /!turnSemantics\\\?\\\.confirmation_decision_made"
    r"\[\\s\\S\]\*isExplicitPetbotConfirmation/\)"
)
new_confirmation = (
    "  assert.match(localChat, /const explicitCurrentMessageConfirmation = Boolean\\([\\s\\S]*"
    "pendingAtTurnStart[\\s\\S]*isExplicitPetbotConfirmation\\(trimmedMessage\\)/)\n"
    "  assert.match(localChat, /const trustedCurrentMessageConfirmation = Boolean\\([\\s\\S]*"
    "explicitCurrentMessageConfirmation[\\s\\S]*turnSemantics\\?\\.confirms_pending_order/)"
)
text = re.sub(old_confirmation, lambda _m: new_confirmation, text)

text = text.replace(
    "  assert.match(settings, /Mensagens padrao/)",
    "  assert.match(settings, /Mensagens padrão/)",
)

# O painel atual usa o componente PetbotDiagnosticSuite, nao o botao antigo de 3 testes.
text = re.sub(
    r"  assert\.match\(([^,]+), /Executar os 3 testes/\)",
    lambda m: f"  assert.match({m.group(1)}, /PetbotDiagnosticSuite/)",
    text,
)

path.write_text(text)

if text == original:
    print('Testes estaticos ja estavam atualizados.')
else:
    print('Testes estaticos atualizados.')
PY

required=(
  scripts/run-luna-scenarios.mjs
  server/lib/luna/operationState.js
  server/lib/luna/operationReducer.js
  server/lib/luna/trace.js
  server/lib/luna/verifier.js
  test/luna/operationReducer.test.mjs
  test/luna/scenarioRunner.test.mjs
)

for file in "${required[@]}"; do
  if [ ! -f "$file" ]; then
    echo "Erro: arquivo esperado nao foi criado: $file" >&2
    exit 1
  fi
done

echo
echo "Executando validacoes..."
node --test test/petbotStatic.test.mjs
npm run test:luna
npm run typecheck
npm run build
git diff --check

# Remove o pacote auxiliar para ele nao entrar no commit.
if [ "$SCRIPT_DIR" = "$ROOT/luna-foundation-recovery" ]; then
  rm -rf "$SCRIPT_DIR"
fi

echo
echo "Validacao concluida sem erros."
echo "Agora execute, uma linha por vez:"
echo "  git add -A"
echo "  git commit -m \"feat(luna): adicionar fundacao de autonomia e regressao\""
echo "  git push -u origin feat/luna-autonomy-foundation"
